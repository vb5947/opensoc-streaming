from kafka import KafkaProducer, KafkaConsumer
from scanner import StringScanner
import sys
import json
import re 
import redis


prod = KafkaProducer(bootstrap_servers = "localhost:9092")
num = 0
cons = 0 #consumer
cont = True
gno=1
count=1

while(1):  
   line=sys.stdin.readline()
   #print line
   if re.search('{"global', line):
       num = num + 1
       prod.send("group1", value=line)
       print line
       #redisconn.setex(count,line,900)
       count=count+1
   elif re.search('end', line):
       #print redisconn.dbsize()
       break
print "\nfinished putting packets into Producer\n Total packets:",num,"Number of groups/topics=",gno
