from __future__ import print_function
from __future__ import division
from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
import json

total=0

def pprinter(segment,drdd,checker):
    num=1000 #for printing first 1000 entries
    def takeAndPrint(time, rdd):
            taken = rdd.take(num + 1)
            nullcheck=0
            if(checker==0): 
                    print ("")
                    print("Time: %s" % time+"\n"+"-"*25+"\n")
                    global total
                    total=0
                    for record in taken[:num]:
                        total=total+record[1]
            if total==0 and checker==0:
                print("No packets in this round \n")
                nullcheck=-1
            elif total==0:
                nullcheck=-1
            elif total!=0 and checker==0:
                print("Total number of packets in this round: "+str(total)+"\n")
            try:
                if (len(taken)==0 or taken[0]==(segment, 0)) and nullcheck!=-1:
                    nullcheck=1
            except Exception:
                nullcheck=0
            if nullcheck==1:
                print (segment)
                print ("-"*len(segment)+"\n")
                print ("No "+segment+"\n")
            elif nullcheck==0:
                print (segment)
                print ("-"*len(segment)+"\n")
                for record in taken[:num]:
                    if record[1]!=0:
                        print(record[0]+": "+str(record[1])+";\t Percentage: "+str(round(float((record[1]/total)*100),2))+"%")
                if len(taken) > num:
                    print("...")
                print("")
            #if(checker==2): print ("----------------------------------")
    drdd.foreachRDD(takeAndPrint) #because this is collection of rdd's, we need to print each rdd

def udper(x):
    try:
        udp_data=x["udp_header"]
        x=str(udp_data["src_port"])+" -> "+str(udp_data["dst_port"])
        return (x,1)
    except Exception:
        return (0,0) 

def tcper(x):
    try:
        tcp_data=x["tcp_header"]
        x=str(tcp_data["src_port"])+" -> "+str(tcp_data["dst_port"])
        return (x,1)
    except Exception:
        return (0,0) 
    
def genper(x):
    if(json.dumps(x["protocol"])!='"UDP"' and json.dumps(x["protocol"])!='"TCP"'):#if there's UDP data, then continue for further analysis
        y=json.dumps(x["prot_data"])
        y=y.split(' ')
        count=1
        fd=""
        for seg in y:
            if seg!=' ' and seg!="" and seg!='\'' and seg!='"':
                fd=fd+" "+seg
            count+=1
        return (json.dumps(x["protocol"])+": "+fd,1)
    else:#if there's no UDP data, return UDP-data with key value 0 so that it can be identified later on and eliminated
        return ("UDP-data",0)

def plendist(x):
    q=int(x)
    if q<=67: return ("=<67",1)
    elif q<=600: return (">67 and =<600",1)
    elif q<=1024: return (">600 and =<1024",1)
    elif q<=1536: return (">1024 and =<1536",1)
    elif q<=2048: return (">1536 and =<2048",1)
    return (">2048",1)



arr=["HOPOPT","ICMP","IGMP","GGP","IPv4","ST","TCP","CBT","EGP","IGP","BBN-RCC-MON","NVP-II","PUP","ARGUS (deprecated)","EMCON","XNET","CHAOS","UDP","MUX","DCN-MEAS","HMP","PRM","XNS-IDP","TRUNK-1","TRUNK-2","LEAF-1","LEAF-2","RDP","IRTP","ISO-TP4","NETBLT","MFE-NSP","MERIT-INP","DCCP","3PC","IDPR","XTP","DDP","IDPR-CMTP","TP++","IL","IPv6","SDRP","IPv6-Route","IPv6-Frag","IDRP","RSVP","GRE","DSR","BNA","ESP","AH","I-NLSP","SWIPE (deprecated)","NARP","MOBILE","TLSP","SKIP","IPv6-ICMP","IPv6-NoNxt","IPv6-Opts","","CFTP","","SAT-EXPAK","KRYPTOLAN","RVD","IPPC","","SAT-MON","VISA","IPCV","CPNX","CPHB","WSN","PVP","BR-SAT-MON","SUN-ND","WB-MON","WB-EXPAK","ISO-IP","VMTP","SECURE-VMTP","VINES","TTP & IPTM","NSFNET-IGP","DGP","TCF","EIGRP","OSPFIGP","Sprite-RPC","LARP","MTP","AX.25","IPIP","MICP (deprecated)","SCC-SP","ETHERIP","ENCAP","","GMTP","IFMP","PNNI","PIM","ARIS","SCPS","QNX","A/N","IPComp","SNP","Compaq-Peer","IPX-in-IP","VRRP","PGM","","L2TP","DDX","IATP","STP","SRP","UTI","SMP","SM (deprecated)","PTP","ISIS over IPv4","FIRE","CRTP","CRUDP","SSCOPMCE","IPLT","SPS","PIPE","SCTP","FC","RSVP-E2E-IGNORE","Mobility Header","UDPLite","MPLS-in-IP","manet","HIP","Shim6","WESP","ROHC","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","Reserved"]
sc = SparkContext(appName="opensoc->kafka->spark")
ssc = StreamingContext(sc, 5)
topic = "group1"
kafkaStream = KafkaUtils.createStream(ssc, "localhost:2181", "group1", {topic: 1})
raw = kafkaStream.flatMap(lambda kafkaS: [kafkaS]).map(lambda x: x[1]).map(lambda x: json.loads(x))
clean = raw.map(lambda x:x["ipv4_header"])#.flatMap(lambda x:(x,1)).reduceByKey(lambda a,b:a+b)
src=clean.map(lambda x: (json.dumps(x["ip_src_addr"]),1)).reduceByKey(lambda a,b:a+b)
dst=clean.map(lambda x: (json.dumps(x["ip_dst_addr"]),1)).reduceByKey(lambda a,b:a+b)
protocol=clean.map(lambda x: json.dumps(x["ip_protocol"])).map(lambda x: (arr[int(x)],1)).reduceByKey(lambda a,b:a+b)
flags=clean.map(lambda x: (json.dumps(x["ip_flags"]),1)).reduceByKey(lambda a,b:a+b)
ttl=clean.map(lambda x: (json.dumps(x["ip_ttl"]),1)).reduceByKey(lambda a,b:a+b)
palen=raw.map(lambda x:x["global_header"]).map(lambda x: plendist(x["orig_len"])).reduceByKey(lambda a,b:a+b)
tcp=raw.map(lambda x: tcper(x)).reduceByKey(lambda a,b:a+b)
udp=raw.map(lambda x: udper(x)).reduceByKey(lambda a,b:a+b)

pprinter("Sources",src,0)
pprinter("Destinations",dst,1)
pprinter("Protocols",protocol,1)
pprinter("Lengths",palen,1)
pprinter("Time to Live",ttl,1)
pprinter("IP Flags",flags,1)
pprinter("TCP-data",tcp,1)
pprinter("UDP-data",udp,1)

ssc.start()
ssc.awaitTermination()
