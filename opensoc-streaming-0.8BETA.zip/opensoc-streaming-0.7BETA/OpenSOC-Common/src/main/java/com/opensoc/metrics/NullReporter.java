package com.opensoc.metrics;

public class NullReporter extends MetricReporter {
	
	public void report()
	{

	}

}
