package com.opensoc.pcap;

import com.opensoc.pcap.PcapByteInputStream;
import com.opensoc.pcap.PacketInfo;
import com.opensoc.pcap.OpenSocEthernetDecoder;
import com.opensoc.pcap.PcapByteOutputStream;
import com.opensoc.pcap.PcapUtils;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.PrintWriter;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.krakenapps.pcap.decoder.ethernet.EthernetDecoder;
import org.krakenapps.pcap.decoder.ethernet.EthernetType;
import org.krakenapps.pcap.decoder.ip.IpDecoder;
import org.krakenapps.pcap.decoder.ipv6.Ipv6Decoder;
import org.krakenapps.pcap.decoder.ip.Ipv4Packet;
import org.krakenapps.pcap.decoder.ip.IpPacket;
import org.krakenapps.pcap.decoder.ipv6.Ipv6Packet;
import org.krakenapps.pcap.decoder.tcp.TcpPacket;
import org.krakenapps.pcap.decoder.udp.UdpPacket;
import org.krakenapps.pcap.file.GlobalHeader;
import org.krakenapps.pcap.packet.PacketHeader;
import org.krakenapps.pcap.packet.PcapPacket;
import org.krakenapps.pcap.util.Buffer;

// TODO: Auto-generated Javadoc
/**
 * The Class PcapParser.
 * 
 * @author sheetal
 * @version $Revision: 1.0 $
 */
public final class PcapParser {

  /** The Constant LOG. */
//  private static final com.sun.istack.internal.logging.Logger LOG = Logger.getLogger(PcapParser.class);

  /** The ETHERNET_DECODER. */
  private static final EthernetDecoder ETHERNET_DECODER = new EthernetDecoder();

  /** The ip decoder. */
  private static final IpDecoder IP_DECODER = new IpDecoder();
  
  private static final Ipv6Decoder IPV6_DECODER = new Ipv6Decoder();

  // /** The tcp decoder. */
  // private static final TcpDecoder TCP_DECODER = new TcpDecoder(new
   //TcpPortProtocolMapper());
  //
  // /** The udp decoder. */
  // private static final UdpDecoder UDP_DECODER = new UdpDecoder(new
 //  UdpPortProtocolMapper());

  static {
     //IP_DECODER.register(InternetProtocol.TCP, TCP_DECODER);
     //IP_DECODER.register(InternetProtocol.UDP, UDP_DECODER);
    ETHERNET_DECODER.register(EthernetType.IPV4, IP_DECODER);
    ETHERNET_DECODER.register(EthernetType.IPV6, IPV6_DECODER);
  }

  /**
   * Instantiates a new pcap parser.
   */
  private PcapParser() { // $codepro.audit.disable emptyMethod

  }

  /**
   * Parses the.
   * 
   * @param tcpdump
   *          the tcpdump
   * @return the list * @throws IOException Signals that an I/O exception has
   *         occurred. * @throws IOException * @throws IOException * @throws
   *         IOException
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   */
  public static List<PacketInfo> parse(byte[] tcpdump) throws IOException {
    List<PacketInfo> packetInfoList = new ArrayList<PacketInfo>();
    PcapByteInputStream pcapByteInputStream = new PcapByteInputStream(tcpdump);

    GlobalHeader globalHeader = pcapByteInputStream.getGlobalHeader();
    IpPacket ipPacket = null;
    int count = 1;
    while (true) {
      try
      {
    	  if (count >10)
    		  break;
    	  //increment count right before the end of try 
    	  
        PcapPacket packet = pcapByteInputStream.getPacket();
  int packetCounter = 0;
         //PacketHeader packetHeader = null;
        TcpPacket tcpPacket = null;
        UdpPacket udpPacket = null;
         //Buffer packetDataBuffer = null;
        int sourcePort = 0;
        int destinationPort = 0;


        ETHERNET_DECODER.decode(packet);
        PacketHeader packetHeader = packet.getPacketHeader();
       	Buffer dat = packet.getPacketData();
       	byte b = dat.get();
       	short s = (short)(b & 0x00ff);
       	int version = (int) ((s >> 4) & 0xf);
       	
        if(version == 6){ //Ipv6Packet stuff
        	
//        	ETHERNET_DECODER.unregister(EthernetType.IPV4, IP_DECODER);
//        	Buffer buff = packet.getPacketData();
        	
//        	Ipv6Packet ipv6Packet = (new Ipv6Packet()).parse(dat);
        	ipPacket = (new Ipv6Packet()).parse(dat);
        	
           	int ihl = (int) (s & 0x00f0);
//        	ipv6Packet.changeTraffic(ihl);
           	((Ipv6Packet) ipPacket).changeTraffic(ihl);
        	
        }
        else{ //Ipv4Packet stuff
            Ipv4Packet ipv4Packet = Ipv4Packet.parse(dat);
            ipv4Packet.setVersion(version);
           	int ihl = (int) ((s & 0x000f)*4);
            ipv4Packet.setIhl(ihl);
			ipPacket = ipv4Packet;
			
        }

        if (ipPacket.getProtocol() == Constants.PROTOCOL_TCP) {
        	tcpPacket = TcpPacket.parse(ipPacket);
        }

        if (ipPacket.getProtocol() == Constants.PROTOCOL_UDP) {

        	Buffer packetDataBuffer = ipPacket.getData();
        	sourcePort = packetDataBuffer.getUnsignedShort();
        	destinationPort = packetDataBuffer.getUnsignedShort();

        	udpPacket = new UdpPacket(ipPacket, sourcePort, destinationPort);

        	udpPacket.setLength(packetDataBuffer.getUnsignedShort());
        	udpPacket.setChecksum(packetDataBuffer.getUnsignedShort());
        	packetDataBuffer.discardReadBytes();
        	udpPacket.setData(packetDataBuffer);

        }
        //        	packetInfoList.add(new PacketInfo(globalHeader, packetHeader, packet,
        //                    ipv4Packet, tcpPacket, udpPacket));

        
        
        
//        System.out.println("it should have added by now");	
        
        //
        if(version == 6)
        {
        	packetInfoList.add(new PacketInfo(globalHeader, packetHeader, packet, (Ipv6Packet) ipPacket, tcpPacket, udpPacket));
        }
        else
        {
        	packetInfoList.add(new PacketInfo(globalHeader, packetHeader, packet, (Ipv4Packet) ipPacket, tcpPacket, udpPacket));
        }
        
  	  count++;  	        
      } catch (NegativeArraySizeException ignored) {
    	  System.out.println("-Array Size Exception triggered---------");
//        LOG.debug("Ignorable exception while parsing packet.", ignored);
      } catch (EOFException eof) { // $codepro.audit.disable logExceptions
        // Ignore exception and break
//    	  System.out.println("end of file --------------------");
    	  break;
      }
    }
    return packetInfoList;
  }

  /**
   * The main method.
   * 
   * @param args
   *          the arguments
   * @throws IOException
   *           Signals that an I/O exception has occurred.
   * @throws InterruptedException
   *           the interrupted exception
   */
  public static void main(String[] args) throws IOException,
      InterruptedException {
	  


    double totalIterations = 1;
    double parallelism = 3;
    double targetEvents = 5;

//    File fin = new File("/Users/Vivek/Documents/Jolata/sample_pcap1.pcap");
//    File fin = new File("/Users/Vivek/Downloads/m00.sctp");
//    File fin = new File("/Users/Vivek/Downloads/ipp-1.pcap");
//    File fin = new File("/Users/Vivek/Downloads/pcap_mult2/every_15/raja.pcap");
    File fin = new File(args[0]);
    File fout = new File(fin.getAbsolutePath() + ".parsed");
    byte[] pcapBytes = FileUtils.readFileToByteArray(fin);
    System.out.println("" + fin.getAbsolutePath() + " = packet file");
    //long startTime = System.currentTimeMillis();
    int count = 1;
    String phrase = "";
    for (int i = 0; i < 1; i++) {
    	
      List<PacketInfo> list = parse(pcapBytes);
      

      for (PacketInfo packetInfo : list) {
        // FileUtils.writeStringToFile(fout, packetInfo.getJsonDoc(), true);
        // FileUtils.writeStringToFile(fout, "\n", true);
    	System.out.println("hi this is part of: " + count);									//
    	count++;
    
        System.out.println(packetInfo.getJsonDoc()+"\n");
        phrase += "" + packetInfo.getJsonDoc();
      }
    }
    System.out.println("end");
//    if (args[1] != null) //args[1] throws IndexOutOfBounds -> need to check for exception 
//    {
//    	PrintWriter writer = new PrintWriter(new File(args[1]));
//    	writer.print(phrase);
//    	writer.close();
//    }
    //double d=Double.valueOf("0x4D3CB2A1");
    //System.out.println("1295823521 == " + d);
    //System.out.println("1295823521 == " + 4D3CB2A1);
    
    /*long endTime = System.currentTimeMillis();

    System.out.println("Time taken to process " + totalIterations + " events :"
        + (endTime - startTime) + " milliseconds");

    System.out
        .println("With parallelism of "
            + parallelism
            + " estimated time to process "
            + targetEvents
            + " events: "
            + (((((endTime - startTime) / totalIterations) * targetEvents) / parallelism) / 1000)
            + " seconds");
    System.out.println("With parallelism of " + parallelism
        + " estimated # of events per second: "
        + ((parallelism * 1000 * totalIterations) / (endTime - startTime))
        + " events");
    System.out.println("Expected Parallelism to process " + targetEvents
        + " events in a second: "
        + (targetEvents / ((1000 * totalIterations) / (endTime - startTime))));*/
  }

}
