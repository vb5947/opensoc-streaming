import sys
import json
import re 
import redis

count=1

while(1):  
   line=sys.stdin.readline()
   if re.search('{"global', line):
       json_op=json.loads(line)
       #redisconn.setex(count,line,900)
       count=count+1
       print json.dumps(json_op)
       sys.stdout.flush()
   elif re.search('end', line):
       #print redisconn.dbsize()
       break
