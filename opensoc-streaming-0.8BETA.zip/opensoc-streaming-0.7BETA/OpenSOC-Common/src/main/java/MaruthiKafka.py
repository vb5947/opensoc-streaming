from kafka import KafkaProducer, KafkaConsumer
from scanner import StringScanner
import sys

prod = KafkaProducer(bootstrap_servers = "localhost:9092")
num = 1
cons = 0 #consumer
cont = True
gno=1

while(cont):
   scanner = StringScanner(sys.stdin.readline())
   if (num-1)%10==0 and num!=1:
       gno=gno+1
   try:
       x = str(num) +"  " +scanner.scan_until("}}")
       print "group"+str(gno),x,"\n"
       prod.send("group"+str(gno), value=x)
       #scanner.skip("\n")
   except Exception:
       cont=False
       break
   num = num + 1
print "\nfinished putting packets into Producer\n Total topics:",num-1
