package com.opensoc.indexing.adapters;

public class SolrAdapter {

}
